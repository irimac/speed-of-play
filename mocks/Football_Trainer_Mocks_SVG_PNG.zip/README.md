
# Football Training App – High-Fidelity Mock Set

Prepared: 2025-12-15 20:25:41
Owner: Ivica Rimac (Nokia) — Stuttgart

This package contains **high-fidelity UI mocks** for the Football Training App. Each screen is provided in **portrait** and **landscape**, with **PNG** (preview) and **SVG** (Figma-ready) versions. Paused overlays are included for all session states.

## Folder Structure
```
/mocks/
  /main/               # Main screen (portrait.png/svg, landscape.png/svg)
  /settings/           # Settings screen
  /session/countdown/  # Session countdown
  /session/active/     # Session active round
  /session/rest/       # Session rest state
  /pause/              # Paused overlays (countdown, active, rest)
  /end/                # End screen (Save to History, End→Main)
  /history/            # History list (checkbox selection, delete, export CSV)
```

## Visual Style
- Material-inspired: rounded buttons, subtle outlines.
- **Active Round** uses a bright green background for high visibility.
- **Rest** uses a neutral background and shows a circular progress ring.
- **Bars** (top/bottom) show round/session timing in large, readable text.
- **Accessibility**: high contrast and large sizes for outdoor readability.

## Notes
- SVGs are simple and Figma-friendly (shapes + text, no heavy filters).
- PNGs are 1080×1920 (portrait) and 1920×1080 (landscape).
- Paused overlays include: Reset Session, Reset Round, Continue, Skip Forward, Finish Session.

## Usage
Import the **SVGs** into Figma for componentization, variants, and design tokens application. Use **PNGs** for immediate sharing and reviews.

MIT © 2025
